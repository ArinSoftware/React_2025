document.addEventListener("DOMContentLoaded", () => {
    const themeToggleBtn = document.getElementById('theme-toggle');
    const themeIcon = document.getElementById('theme-icon');

    // Check saved theme in localStorage
    if (localStorage.getItem('theme') === 'light') {
        document.body.classList.add('light-mode');
        themeIcon.src = 'img/moon.png';
    } else {
        document.body.classList.add('dark-mode');
        themeIcon.src = 'img/sun.png';
    }

    themeToggleBtn.addEventListener('click', () => {
        console.log("CLICKED")
        if (document.body.classList.contains('dark-mode')) {
            document.body.classList.remove('dark-mode');
            document.body.classList.add('light-mode');
            themeIcon.src = 'img/moon.png';
            localStorage.setItem('theme', 'light');
        } else {
            document.body.classList.remove('light-mode');
            document.body.classList.add('dark-mode');
            themeIcon.src = 'img/sun.png';
            localStorage.setItem('theme', 'dark');
        }
    });
});